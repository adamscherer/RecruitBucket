define([
    'jQuery',
    'Underscore',
    'Backbone',
    'router',
    'models/session',
    'Bootstrap',
    'views/sub/header',
    'views/sub/sidebar',
    'views/modals/login'
], function($, _, Backbone, Router, Session) {

    var HeaderView = require('views/sub/header');
    var SidebarView = require('views/sub/sidebar');
    var LoginModalView = require('views/modals/login');

    var initialize = function() {
        this.mainBody = $('#main-body');

        this.loginModal = new LoginModalView({
            el : $("#modals")
        });

        this.sidebarView = new SidebarView({
            el : $("#sidebar")
        });

        this.headerView = new HeaderView({
            el : $("#header")
        });

        Session.bind('change:auth', function(authenticated) {
            if (authenticated) {
                Router.initialize();
                this.mainBody.removeClass('hide');
            } else {
                this.mainBody.addClass('hide');
            }
        }.bind(this));

        Session.getAuth();
    }

    return {
        initialize : initialize
    };
});
