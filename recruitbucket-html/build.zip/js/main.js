require.config({
    paths : {
        loader : 'libs/backbone/loader',
        jQuery : 'libs/jquery/jquery',
        Underscore : 'libs/underscore/underscore',
        Backbone : 'libs/backbone/backbone',
        Bootstrap : 'libs/bootstrap/bootstrap.min',
        GlobalEvents : 'global',
        templates : '../templates',
        GoogleMaps : 'libs/google-maps',
        jQuery_serialize : 'libs/jquery/jquery-serialize',
        async : 'libs/async',
        order : 'libs/order',
        text : 'libs/text'
    }
});

require([
    // Load our app module and pass it to our definition function
    'jQuery', 'Underscore', 'Backbone', 'app'

// Some plugins have to be loaded in order due to their non AMD compliance
// Because these scripts are not "modules" they do not pass any values to the
// definition function below
], function($, _, Backbone, App) {

    // Expose Underscore globally to ease template rendering
    window._ = _;

    Backbone.emulateHTTP = true;

    // The "app" dependency is passed in as "App"
    // Again, the other dependencies passed in are not "AMD" therefore don't
    // pass a parameter to this function
    App.initialize();
});
