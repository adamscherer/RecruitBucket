define([
    'jQuery', 'Underscore', 'Backbone'
], function($, _, Backbone) {
    var RecruitModel = Backbone.Model.extend({

        urlRoot : '/api/recruit',
        initialize : function() {

        }

    });

    return RecruitModel;
});