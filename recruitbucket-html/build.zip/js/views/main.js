define([
    'require',
    'jQuery',
    'Underscore',
    'Backbone',
    'GlobalEvents',
    'text!templates/main.html',
    'views/main/status',
    'views/main/top-recruits',
    'views/main/activity',
    'views/main/recruit-statistics',
    'views/main/recruit-map',
    'views/main/interviewer-statistics',
    'models/statistic',
], function(require, $, _, Backbone, GlobalEvents, MainTemplate) {

    var StatusView = require('views/main/status');
    var TopRecruitsView = require('views/main/top-recruits');
    var ActivityView = require('views/main/activity');
    var RecruitStatisticsView = require('views/main/recruit-statistics');
    var RecruitMapView = require('views/main/recruit-map');
    var InterviewerStatisticsView = require('views/main/interviewer-statistics');
    var Statistics = require('models/statistic');

    var View = Backbone.View.extend({
        render : function() {

            Statistics.fetch();

            this.$el.html(MainTemplate);

            new StatusView({
                el : $("#status-section")
            });

            new TopRecruitsView({
                el : $("#top-recruits-widget")
            });

            new RecruitStatisticsView({
                el : $("#recruit-statistics-widget")
            });

            new RecruitMapView({
                el : $("#recruit-map-widget")
            });

            new ActivityView({
                el : $("#activity-widget")
            });

            new InterviewerStatisticsView({
                el : $("#interviewer-statistics-widget")
            });

            GlobalEvents.trigger('render:sidebar', 'dashboard');
        }
    });

    return new View({
        el : $("#body")
    });
});