define([
    'jQuery',
    'Underscore',
    'Backbone',
    'models/session',
    'collections/activities',
    'text!templates/main/activity.html'
], function($, _, Backbone, Session, ActivitiesCollection, template) {

    var View = Backbone.View.extend({
        initialize : function() {
            _.bindAll(this, "render");

            // Once the collection is fetched re-render the view
            ActivitiesCollection.bind("reset", this.render);
            ActivitiesCollection.fetch();
        },
        render : function() {
            this.$el.html(_.template(template, {
                data : {
                    activities : ActivitiesCollection.models[0].attributes.content
                },
                _ : _
            }));
            
            //ActivitiesCollection.startListener();
        }
    });

    return View;
});