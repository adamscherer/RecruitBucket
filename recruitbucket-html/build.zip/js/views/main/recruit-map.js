define([
    'jQuery',
    'Underscore',
    'Backbone',
    'GoogleMaps',
    'models/session',
    'collections/recruits',
    'text!templates/main/recruit-map.html'
], function($, _, Backbone, GoogleMaps, Session, RecruitsCollection, template) {

    var View = Backbone.View.extend({
        template : _.template(template),
        initialize : function() {
            this.render();
        },
        render : function() {
            this.$el.html(this.template());

            var mapCanvas = $("#utopia-google-map-5").get(0);

            GoogleMaps.addMapToCanvas(mapCanvas);
        }
    });

    return View;
});