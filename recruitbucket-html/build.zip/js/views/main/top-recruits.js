define([
    'jQuery',
    'Underscore',
    'Backbone',
    'collections/recruits',
    'text!templates/main/top-recruits.html'
], function($, _, Backbone, RecruitsCollection, template) {

    var View = Backbone.View.extend({
        initialize : function() {
            _.bindAll(this, "render");

            // Once the collection is fetched re-render the view
            RecruitsCollection.bind("reset", this.render);
            RecruitsCollection.fetch();
        },
        render : function() {
            this.$el.html(_.template(template, {
                data : {
                    recruits : RecruitsCollection.models[0].attributes.content
                },
                _ : _
            }));
        }
    });

    return View;
});