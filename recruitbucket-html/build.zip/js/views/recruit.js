define([
    'jQuery',
    'Underscore',
    'Backbone',
    'GlobalEvents',
    'models/recruit',
    'text!templates/recruit.html',
    'views/modals/basic-info-edit'
], function($, _, Backbone, GlobalEvents, RecruitModel, Template) {

    var BasicEditModal = require('views/modals/basic-info-edit');

    var View = Backbone.View.extend({
        template : _.template(Template),
        initialize : function() {
            _.bindAll(this, "load", "render", "basicEdit");
        },
        render : function() {
            console.log('render recruit');
            this.$el.html(this.template({
                data : this.model.toJSON()
            }));

            GlobalEvents.trigger('render:sidebar', 'recruits');
        },

        events : {
            "click #edit-basic" : "basicEdit"
        },

        basicEdit : function(ev) {
            BasicEditModal.showModal(this.model);

            return false;
        },

        load : function(id) {
            this.model = new RecruitModel({
                id : id
            });
            this.model.bind("change", this.render);
            this.model.fetch();
        }
    });

    return new View({
        el : $("#body")
    });
});
