define([
    'jQuery',
    'Underscore',
    'Backbone',
    'GlobalEvents',
    'text!templates/recruits.html',
    'views/recruits/recruit-list',
    'views/recruits/add-recruit',
    'views/main/recruit-map'
], function($, _, Backbone, GlobalEvents, Template) {

    var RecruitListView = require('views/recruits/recruit-list');
    var AddRecruitView = require('views/recruits/add-recruit');
    var RecruitMapView = require('views/main/recruit-map');

    var View = Backbone.View.extend({
        render : function() {

            this.$el.html(Template);

            new RecruitListView({
                el : $("#recruit-list-widget")
            });

            new AddRecruitView({
                el : $("#add-recruit-widget")
            });

            new RecruitMapView({
                el : $("#recruit-map-widget")
            });

            GlobalEvents.trigger('render:sidebar', 'recruits');
        }
    });

    return new View({
        el : $("#body")
    });
});
