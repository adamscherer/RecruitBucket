define([
    'jQuery', 'Underscore', 'Backbone', 'text!templates/recruits/add-recruit.html'
], function($, _, Backbone, template) {

    //Since this data is submitted to an IFRAME, we are adding an accessible callback function.
    var callbackFunctionName = 'addRecruitCallback';
    var callback = function(data) {
        Backbone.history.navigate('recruit/' + data.id, {trigger: true});
    };

    var View = Backbone.View.extend({
        template : _.template(template),
        initialize : function() {
            this.render();

            window[callbackFunctionName] = callback;
        },
        render : function() {
            this.$el.html(this.template());
        }
    });

    return View;
});