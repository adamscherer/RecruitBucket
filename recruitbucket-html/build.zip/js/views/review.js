define([
    'jQuery',
    'Underscore',
    'Backbone',
    'GlobalEvents',
    'models/review',
    'text!templates/review.html',
    'views/modals/basic-info-edit'
], function($, _, Backbone, GlobalEvents, ReviewModel, Template) {

    var BasicEditModal = require('views/modals/basic-info-edit');

    var View = Backbone.View.extend({
        template : _.template(Template),
        initialize : function() {
            _.bindAll(this, "load", "render", "basicEdit");
        },
        render : function() {
            console.log('render recruit');
            this.$el.html(this.template({
                data : this.model.toJSON()
            }));

            GlobalEvents.trigger('render:sidebar', 'recruits');
        },

        events : {
            "click #edit-basic" : "basicEdit"
        },

        basicEdit : function(ev) {
            //BasicEditModal.showModal(this.model);

            return false;
        },

        load : function(id, reviewId) {
            this.model = new ReviewModel({
                recruitId : id
            });
            this.model.bind("change", this.render);
            //this.model.fetch();
            
            //this.render();
        }
    });

    return new View({
        el : $("#body")
    });
});