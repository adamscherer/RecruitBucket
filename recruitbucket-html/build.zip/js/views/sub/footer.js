define([
    'jQuery', 'Underscore', 'Backbone', 'text!templates/footer.html'
], function($, _, Backbone, template) {

    var View = Backbone.View.extend({
        render : function() {
            this.$el.html(template);
        }
    });

    return new View({
        el : $("footer")
    });
});
