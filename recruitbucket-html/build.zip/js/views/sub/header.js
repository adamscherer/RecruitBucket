define([
    'jQuery', 'Underscore', 'Backbone', 'models/session', 'text!templates/header.html'
], function($, _, Backbone, Session, template) {

    var View = Backbone.View.extend({
        template : _.template(template),
        initialize : function() {
            this.render();
        },
        events : {
            "click #logout" : "logout",
            "click .user-info" : "handleDropdown"
        },
        render : function() {
            this.$el.html(this.template());
        },

        logout : function(ev) {
            Session.logout();

            return false;
        },

        handleDropdown : function(ev) {
            var active = $(ev.currentTarget);
            var dropDown = $('.user-dropbox');
            if (!active.hasClass('user-active')) {
                dropDown.slideDown('fast');
                active.addClass('user-active');
            } else {
                active.removeClass('user-active');
                dropDown.hide();
            }

            return false;
        }
    });

    return View;
});
