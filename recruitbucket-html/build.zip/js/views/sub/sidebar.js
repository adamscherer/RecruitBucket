define([
    'jQuery', 'Underscore', 'Backbone', 'GlobalEvents', 'text!templates/sidebar.html'
], function($, _, Backbone, GlobalEvents, template) {

    var View = Backbone.View.extend({
        template : _.template(template),
        initialize : function() {
            this.render();
            this.bindGlobalEvents();
        },
        render : function() {
            this.$el.html(this.template());
        },
        bindGlobalEvents : function() {
            var menuItems = this.$el.find('.leftmenu ul li');
            GlobalEvents.bind('render:sidebar', function(selectedItem) {
                menuItems.each(function() {
                    var item = $(this);
                    item.removeClass('current');
                    
                    if (item.attr('id') === selectedItem) {
                        item.addClass('current');
                    }
                });
            });
        }
    });

    return View;
});