define([
    'jQuery',
    'Underscore',
    'Backbone',
    'GlobalEvents',
    'text!templates/training.html',
    'views/main/top-recruits'
], function($, _, Backbone, GlobalEvents, Template) {

    var TopRecruitsView = require('views/main/top-recruits');

    var View = Backbone.View.extend({
        render : function() {

            this.$el.html(Template);

            //new TopRecruitsView({
            //    el : $("#top-recruits-widget")
            //});
            
            GlobalEvents.trigger('render:sidebar', 'training');
        }
    });

    return new View({
        el : $("#body")
    });
});